const express = require('express');
const request = require('request');
const app = express();

app.use((req, res, next) => {
   res.header('Access-Control-Allow-Origin', '*');
   res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
   next();
});

app.get('/proxy', (req, res) => {
   request(
      { url: 'https://omscloud.aslbelgisi.uz/api/v2/beer/orders' },
      (error, response, body) => {
         if (error) {
            return res.status(500).send(error);
         }
         res.send(body);
      }
   );
});

app.listen(3000, () => {
   console.log('Proxy server running on port 3000');
});