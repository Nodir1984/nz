import React, { useState } from 'react';

function App() {

  const [formData, setFormData] = useState({
    omsid: '',
    token: '',
    inn: '',
    productGroup: '',
    contactPerson: '',
    releaseMethod: '',
    code: '',
    quantity: '',
    type: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const sendDataUsingXHR = () => {

    console.log('Form Data:', formData);

    var myRequest = new XMLHttpRequest();
    myRequest.open('POST', `https://omscloud.aslbelgisi.uz/api/v2/beer/orders?omsid=${formData.omsid}`, true);
    myRequest.setRequestHeader('Content-Type', 'application/json');
    myRequest.setRequestHeader('Authorization', `Bearer ${formData.token}`);

    myRequest.onreadystatechange = function () {
      console.log('ReadyState:', myRequest.readyState); // Add logging for readyState
      if (myRequest.readyState === 4) {
        console.log('Status:', myRequest.status); // Log the status code
        if (myRequest.status === 200) {
          console.log('Success:', JSON.parse(myRequest.responseText));
          alert('Данные успешно отправлены!');
        } else {
          console.error('Ошибка:', myRequest.statusText, myRequest.responseText); // Log more detailed error info
          alert('Ошибка при отправке данных.');
        }
      }
    };

    const requestBody = {
      products: [
        {
          gtin: formData.code,
          quantity: Number(formData.quantity),
          serialNumberType: "SELF_MADE",
          templateId: 18,
          cisType: formData.type
        }
      ],
      contactPerson: formData.contactPerson,
      releaseMethodType: formData.releaseMethod,
      createMethodType: "SELF_MADE",
      productionOrderId: "08528091-808a-41ba-a55d-d6230c64b327"
    };

    // Send the request
    try {
      myRequest.send(JSON.stringify(requestBody));
      console.log('Request Body:', requestBody); // Log the request body
    } catch (error) {
      console.error('Ошибка при отправке запроса:', error);
    }
  };

  return (
    <div className="flex flex-col items-center p-6">
      <input
        className="border rounded p-2 w-full"
        type="text"
        name="omsid"
        placeholder="OMSID"
        required
        value={formData.omsid}
        onChange={handleChange}
      />
      <input
        className="border rounded p-2 w-full"
        type="text"
        name="token"
        placeholder="Token"
        required
        value={formData.token}
        onChange={handleChange}
      />
      <input
        className="border rounded p-2 w-full"
        type="text"
        name="inn"
        placeholder="INN"
        required
        value={formData.inn}
        onChange={handleChange}
      />
      <input
        className="border rounded p-2 w-full"
        type="text"
        name="productGroup"
        placeholder="Группа товаров"
        required
        value={formData.productGroup}
        onChange={handleChange}
      />
      <input
        className="border rounded p-2 w-full"
        type="text"
        name="contactPerson"
        placeholder="Контактное лицо"
        required
        value={formData.contactPerson}
        onChange={handleChange}
      />
      <input
        className="border rounded p-2 w-full"
        type="text"
        name="releaseMethod"
        placeholder="Способ выпуска товаров"
        required
        value={formData.releaseMethod}
        onChange={handleChange}
      />
      <input
        className="border rounded p-2 w-full"
        type="text"
        name="code"
        placeholder="Код товара"
        required
        value={formData.code}
        onChange={handleChange}
      />
      <input
        className="border rounded p-2 w-full"
        type="number"
        name="quantity"
        placeholder="Количество КМ"
        required
        value={formData.quantity}
        onChange={handleChange}
      />
      <input
        className="border rounded p-2 w-full"
        type="text"
        name="type"
        placeholder="Тип кода маркировки"
        required
        value={formData.type}
        onChange={handleChange}
      />
      <button
        type="button"
        className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-700"
        onClick={sendDataUsingXHR} // Trigger XMLHttpRequest on button click
      >
        Отправить
      </button>
    </div>
  );
}

export default App;
